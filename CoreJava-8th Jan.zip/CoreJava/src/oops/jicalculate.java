package oops;

public class jicalculate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		J1 c=new J1();
		c.inputd();
		c.calculate();
		c.Display();	

	}

}

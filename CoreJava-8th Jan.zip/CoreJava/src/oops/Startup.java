package oops;

public class Startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//create object of class
		Employee e1 = new Employee();
		e1.newEmployee();
		
		Employee e2 = new Employee();
		e2.newEmployee();
		
		e1.calculate();
		e2.calculate();
		
		e2.showDeails();
		e1.showDeails();
		
		//print object address 
		System.out.println(e1);
		System.out.println(e2);
	}

}

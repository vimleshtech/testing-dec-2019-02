package oops;

import java.util.Scanner;

//class
public class Employee {

	//data member or member variable or attribute 
	int eid;
	String name;
	int sal;
	double hra,da,msal,ysal;

	//construtor 
	Employee()
	{
		System.out.println("object is created, welcome to function world...!");
	}
	//method
	void newEmployee() {
		
		Scanner sc =new Scanner(System.in);
		System.out.println("enter eid, name, salary :");
		eid = sc.nextInt();
		name = sc.next();
		sal = sc.nextInt();
		
	}
	
	void calculate() {
		
		hra = sal*.50;
		da = sal*.40;
		msal = sal+hra+da;
		ysal = msal*12;
		
	}
	void showDeails() {
		
		
		System.out.println("****Employee Details*****");
		System.out.println("Employee id is "+eid);
		System.out.println("Employee name is "+name);
		System.out.println("Employee sal is "+sal);
		System.out.println("msal is "+msal);
		System.out.println("ysal is "+ysal);
		
	}
	
	
	
	
}

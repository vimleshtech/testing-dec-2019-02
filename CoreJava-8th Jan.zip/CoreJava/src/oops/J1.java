package oops;

import java.util.Scanner;

public class J1 {
//WAP to input rollno, name and marks in five subjects and calculate the total and average marks through classes. 
	// Define different functions to input, calculate and display the data.
	
	
		int rollno,a,b,c,d,e,total;
		String name;
		double avg;
		
		void inputd() {
			
			Scanner sc =new Scanner(System.in);
			System.out.println("enter roll No.");
			rollno = sc.nextInt();
			System.out.println("enter name");
			name = sc.next();
			System.out.println("enter Subject marks of a ");
			a= sc.nextInt();
			System.out.println("enter Subject marks of b");
			b= sc.nextInt();
			System.out.println("enter Subject marks of c");
			c= sc.nextInt();
			System.out.println("enter Subject marks of d");
			d= sc.nextInt();
			System.out.println("enter Subject marks of e");
			e= sc.nextInt();
			}
		void calculate() {
			total =a+b+c+d+e;
			avg=total/5;
			System.out.println("total marks is : "+total);
			System.out.println("Average marks is : "+avg);
		}
		void Display() {
			System.out.println("Student name is : " +name);
			System.out.println("Roll No. is : "+rollno);
			System.out.println("Marks of a : "+a);
			System.out.println("Marks of b : "+b);
			System.out.println("Marks of c : "+c);
			System.out.println("Marks of d : "+d);
			System.out.println("Marks of e : "+e);
			
			
		}

}

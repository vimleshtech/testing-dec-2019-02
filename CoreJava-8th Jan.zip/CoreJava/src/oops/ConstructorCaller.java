package oops;

public class ConstructorCaller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConstructorExample c =new ConstructorExample(); //1
		c.newName("nitin");
		c.show();
		
		ConstructorExample cc =new ConstructorExample("india"); //2
		ConstructorExample c1 =new ConstructorExample(c); //3
		c1.show();
		
		
		
	}

}

package oops;

import java.util.Scanner;

public class J2 {
	
	int Ecode[]=new int[10];			
	String Ename[]=new String[10];
	int Basic_salary[]=new int[10];		
	float Hra,Da,Ta,Gross_salary,It,Pf,Net_salary;
	

	
	void Input() {
			 Scanner sc=new Scanner(System.in);
			 for(int i=0;i<10;i++) {
			 System.out.println("Enter Employee code");
			 Ecode[i]=sc.nextInt();
			 }
			 for(int i=0;i<10;i++) {
				 System.out.println("Enter Employee name");
				 Ename[i]=sc.next();
				 }
			 for(int i=0;i<10;i++) {
				 System.out.println("Enter Employee basic salary");
				Basic_salary[i]=sc.nextInt();
			 }
			 
			 sc.close();
// function to input the values for ecode, ename and basic salary

		 }
	
		 void calc(){
			 for(int i=0;i<10;i++) {
				    Hra=Basic_salary[i]*(0.4f);
					Da=(0.2f)*Basic_salary[i];
					Ta=(0.1f)*Basic_salary[i];
					Gross_salary=Basic_salary[i]+Hra+Da+Ta;
					It=(0.20f)*Gross_salary;
					Pf=(0.1f)*Gross_salary;
					Net_salary=Gross_salary*(It+ Pf);
					 }
	System.out.println(Net_salary);
		 }
		 void disp()	{
			 for(int i=0;i<10;i++) { 
			 System.out.println("Employee code  : "+Ecode[i]);
			 System.out.println("Employee name  : "+Ename[i]);
			 System.out.println("Employee Basic salary  : "+Basic_salary[i]);
			 
			 }
	
		 }



}

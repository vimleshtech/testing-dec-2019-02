package oops;

public class ConstructorExample {

	String name;
	
	//without argument constructor 
	ConstructorExample(){
		System.out.println("in default constructor");
	}
	
	//with argument constructor 
	ConstructorExample(String country){
		
		System.out.println("in argument constructor "+country);
	}
	//copy constructor , take previous obejct refrence 
	ConstructorExample(ConstructorExample obj){
		System.out.println("in copy construcotr "+obj);
		name = obj.name;
	}
	
	void newName(String n) {
		name =n;
	}
	void show() {
		System.out.println(name);
	}
}


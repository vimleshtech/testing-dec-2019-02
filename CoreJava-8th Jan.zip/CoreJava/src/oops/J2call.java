package oops;

public class J2call {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	J2 a=new J2();
	a.Input();
	a.calc();
	a.disp();

	}

}

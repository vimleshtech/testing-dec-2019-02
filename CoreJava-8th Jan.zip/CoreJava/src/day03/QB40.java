package day03;

import java.util.Scanner;

public class QB40 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub

			Scanner s = new Scanner(System.in);
			int sn,en;
			
			System.out.println("enter first num ");
			sn = s.nextInt();
			
			
			System.out.println("enter 2nd num ");
			en = s.nextInt();
			
			int sum = 0;
			
			while(sn<=en) 
			{
				
				if(sn%2 ==0 && sn%3 ==0 && sn%5 !=0 )
					sum+= sn;
				sn++;
			}
			
			System.out.println(sum);
			
			
			
		}

		
	}
			


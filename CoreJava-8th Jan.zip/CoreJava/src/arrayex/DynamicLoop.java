package arrayex;

import java.util.Scanner;

public class DynamicLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int size;
		System.out.println("enter array size ");
		size = sc.nextInt();
		
		int n[] = new int[size];
		
		for(int i=0; i<size;i++) {
		
			System.out.println("enter data for array  ");
			n[i]= sc.nextInt();
			
			
		}
		
		//print
		for(int d: n) {
			System.out.println(d);
		}
		
	}

}

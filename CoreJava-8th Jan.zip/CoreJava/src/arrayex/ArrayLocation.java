package arrayex;

public class ArrayLocation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		greater();
		reverse();
		sort();	}
	public static void greater() {
		int a[] = {1,2,5,4};
		int lar = 0;
		int seclar =0;
		int c=0;
		int d=0;
		
		
		for(int i=0;i<=3;i++) {
			
		if(lar<a[i])
		{
			seclar=lar;
			lar =a[i];
			c=i;
			
		}else if(seclar<a[i]) {
			seclar=a[i];
			d=i;
			
		}
	
		}System.out.println(lar);
		System.out.println(c);
		System.out.println(seclar);
		System.out.println(d);
		
		
	}
	public static void reverse() {
	int a[] = {1,2,5,4};
	for(int i=3; i>=0;i--) {
		System.out.print(a[i]);}
	}
	public static void sort() {
		int a[] = {1,2,2,4};
		int max =a[0];
		int min =a[0];
		for(int i=0; i>=3;i++) {
			if(a[i]>max) {
			max =a[i];
			}
			if(min<a[i]) {
			min=a[i];
			}
			
			System.out.println(max);
			}
		}
	
		
		
		
		
	

}

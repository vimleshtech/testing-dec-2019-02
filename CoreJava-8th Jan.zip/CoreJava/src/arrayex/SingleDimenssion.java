package arrayex;

import java.net.SocketTimeoutException;

public class SingleDimenssion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n[]= {11,33,55,454};
		System.out.println(n);
		System.out.println(n[0]); //print first elements
		
		System.out.println(n.length); //count 
		for(int i=0;i<n.length;i++) {
			System.out.println(n[i]);
		}
		
		//or
		for(int d: n) {
			System.out.println(d);
		}
		
		
	}

}

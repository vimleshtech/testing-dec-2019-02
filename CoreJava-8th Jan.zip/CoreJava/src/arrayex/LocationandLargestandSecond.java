package arrayex;

public class LocationandLargestandSecond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[] = {1,2,3,4};
		
		for(int i=0;i<=3;i++) {
			
		if(a[i]>a[i+1])
		{
			a[i+1]=a[i];
			System.out.println(a[i]);
			System.out.println(i);
		}
		else {
			a[i]=a[i+1];
		}
		}
//finds the locations and values of largest and second largest element in a one dimensional array.

	}

}

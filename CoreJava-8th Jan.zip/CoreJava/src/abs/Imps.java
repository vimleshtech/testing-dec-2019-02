package abs;

public class Imps extends Test {

	@Override
	public void add(int a, int t) {
		// TODO Auto-generated method stub
	
		System.out.println(a+t);
	}

}

package day05;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e = new Employee();
		
		e.newEmployee();
		e.salCalculation();
		e.show();
		
	}

}

package day05;

import java.util.Scanner;

public class Employee {

	//data members//attribuates
	int eid;
	String name;
	int bsal;
	double hra,da,msal,ysal;
		
	//methods
	void newEmployee() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter eid ");
		eid = sc.nextInt();
		
		
		System.out.println("enter name");
		name = sc.next();
		
		System.out.println("enter basic sal");
		bsal= sc.nextInt();
		
		
	}	
	void salCalculation() {
		hra = bsal*.40;
		da= bsal*.20;
		msal= hra+da+bsal;
		ysal = msal*12;
				
	}
	void show() {
	
		System.out.println("employee id is "+eid);
		System.out.println("name is "+name);
		System.out.println("monthly sal is "+msal);
		System.out.println("yearly sal is "+ysal);
		
	}
	
	
}

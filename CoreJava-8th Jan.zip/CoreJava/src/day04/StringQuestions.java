package day04;

import java.util.Scanner;

public class StringQuestions {

	public static void main(String[] args) {

		String s,c;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter string :");
		s = sc.nextLine();
		
		System.out.println("enter char :");
		c = sc.next();
				
		///String Q1. this is java code		
		System.out.println(s.length() - s.replace(" ", "").length());
		System.out.println(s.length() - s.replace("\t", "").length());
		System.out.println(s.length() - s.replace("\n", "").length());
			
		
		///String Q2. 
		//abacdxyA
		//a
		//System.out.println(s.replace(c, c.toUpperCase()));
		
		for(int i=0;i<s.length();i++) {
			
			char ss = s.charAt(i);
			int n = ss; //ascii 
			if(n>=65 && n<=91 && c.equalsIgnoreCase(ss+"")) {
			
				System.out.print(s.substring(i,i+1).toLowerCase());
				
			}else if(n>=97 && n<=122 && c.equalsIgnoreCase(ss+"")) {
				
				System.out.print(s.substring(i,i+1).toUpperCase());
				
			}else {
				System.out.print(s.substring(i,i+1));
			}
		}
					
		
			///String Q3. this is java code
			System.out.println(s.length() - s.replace(" ", "").length()+1);
			//or
			System.out.println( (s.split(" ")).length ); 
			
			System.out.println(s.length() - s.replace(" ", "").length());
			
			System.out.println(s.replace(" ", "").length());
			
			///String Q4. this Is java Code			
			String nn[] = s.split(" ");
			
			//for(String word : nn) {
			for(int i=0; i<nn.length;i++) {
				
				int asc =(int) nn[i].charAt(0);
				
				if(asc>=65 && asc<=91 ) {					
					System.out.println(nn[i]);				
					
				}
					
			
		}
		
	}

}

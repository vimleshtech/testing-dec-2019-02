package day04;

import java.util.Scanner;

public class FunctionExample {

	public static void main(String[] args) 
	{
		//call to function 
		welcome();
		welcome();
		
		int a,b;
		a = getNumber();
		b = getNumber();
		
		System.out.println(a+b);
		
		//call to function with argument
		add(a,b);
		add(44,455);
		
		//
		int o = sub(a,b);
		System.out.println("sub of numbers "+o);
		
		//return output can be reused
		add(o,100);

		//Call to recussive function 
		int f = fact(5);
		System.out.println(f);
		
		
	}

	//No argument no return 
	public static void welcome() {		
		System.out.println("Welcome to function world !!!");		
	}
	
	//No argument with return 
	public static int getNumber() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter data ");
		int n = sc.nextInt();
		
		return n;
	}
	
	//Argument with no return 
	public static void add(int a, int b) {		
		System.out.println(a+b);		
	}
	
	//Argument with  return 
	public static int sub(int a, int b) {		
		return a-b;		
	}
		
	
	//Recussive function
	public static int fact(int n) {
		if(n==1) {
			return n;
		}else {
			
			return n*fact(n-1);
		}
	}
	
}

package day04;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileHnalder {

	public static void main(String[] args) throws FileNotFoundException {
	
		FileReader fr = new FileReader("c://abcd//a.txt");
		

	}

}

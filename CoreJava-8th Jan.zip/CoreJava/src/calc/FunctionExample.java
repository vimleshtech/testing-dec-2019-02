package calc;

import java.util.Scanner;

/*
 * Function : is set of instructions or command which is reusable 
 * Types of function:
 * -No argument no reutrn
 * -No argument with return
 * -Argument with return
 * -Argument with no return
 * -Other type of function : Recurssive function (function which invokes itself)
 */

public class FunctionExample {

	public static void main(String[] args) {
		
		//call to function 
		welcome();
		welcome();
		welcome();
		
		//
		int a,b;
		a = getNumber();
		b = getNumber();
		
		System.out.println(a+b);
		
		//
		add(11,232);
		add(a,b);
	
		//call to function and recieve data
		int c = sub(111, 3);
		System.out.println(c);
		
		//fact 
		int f = fact(6);
		System.out.println(f);
	}

	
	//No argument no return 
	public static void welcome() {
		
		System.out.println("Test function ");
	}
	//No argument with return
	public static int getNumber() {
		
		Scanner s = new Scanner(System.in);
		System.out.println("enter data ");
		int n = s.nextInt();
		return n;
	}
	
	//Argument with no return 
	public static void add(int a, int b) {
		
		int c =a+b;
		System.out.println(c);
	}
	
	//Argument with return
	public static int sub(int a, int b) {
		return a-b;
	}
	
	//Recurssive function 
	public static int fact(int n) {
		
		if(n==1) {
			return n;
		}else {
			
			return n*fact(n-1);
		}
		
	}
}

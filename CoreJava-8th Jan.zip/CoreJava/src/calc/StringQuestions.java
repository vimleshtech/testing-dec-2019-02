package calc;

import java.util.Scanner;

public class StringQuestions {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String s;
		
		System.out.println("ENTER STRING");
		s = sc.nextLine();
		
		//this Is java Code
		String words[] = s.split(" "); //{"this","Is","java","Code"}
		
		//convert char to ASCII 
		//A = 65  , Z = 91
		//a = 97 to z = 122
		
		for(int i=0;i<words.length;i++) {
			
			//this
			char c = words[i].charAt(0);
			int n = c; //convert to assci code
			//System.out.println(n);
			
			if(n>=65 && n<=91) {
				System.out.println(words[i]);
			}
			
		}

		///QC7
		System.out.println("ENTER CHAR TO SEARCH");
		String news = sc.nextLine();
		
		if(s.indexOf(news)>-1) {
			
			System.out.println("char is match");
		}
		else {
			System.out.println("char is not match");
		}
				
		//Question C5
		//digit = 48 - 57
		//Cap letter = 65 - 91
		//s = this is java code
		
		int dc=0,cs=0,vc=0,scount=0;
		String v="aeiou";
		
		for(int i=0; i<s.length();i++) {
			
			char c = s.charAt(i);
			int n= c; //get ascii
			
			if(n>=48 && n<=57) {
			
				dc+=1;
			}
			else if((n>=65 && n<=91) || (n>=97 && n<=122) && v.indexOf(c)<0 ) {
				cs+=1;				
			}
			else if(v.indexOf(c)>-1 ) {
				vc+=1;
			}else {
				scount+=1;
			}
		}
		
		System.out.println("digit count: "+dc);
		System.out.println("constaint  count: "+cs);
		System.out.println("vowel count: "+vc);
		System.out.println("speical char count: "+scount);
	}

}

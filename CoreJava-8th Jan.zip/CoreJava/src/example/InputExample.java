package example;

//import package
import java.util.Scanner;


public class InputExample {

	public static void main(String[] arg) {
		

		//create object of Scanner
		Scanner s = new Scanner(System.in);
		int a,b,c;
		String name;
		
		
		System.out.println("enter num ");
		a = s.nextInt(); //nextInt() is function which read numeric value
		
		System.out.println("enter num ");
		b = s.nextInt();
		
		
		System.out.println("enter name ");
		name = s.next(); //next() is functino which read string word
		
		c =a+b;
		System.out.println("out is "+c);
		System.out.println("name is  "+name);
		
		
	}
}

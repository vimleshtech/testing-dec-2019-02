package example;
import java.util.Scanner;
public class First1 {

	public static void main(String[] args) 
	{
		Scanner R=new Scanner(System.in);
		int roll_no,marks,ph_no;
		String Student_name;
		
		System.out.println("enter roll number");		
		roll_no=R.nextInt();
		
		System.out.println("enter marks");
		marks=R.nextInt();
		
		System.out.println("please provide phone number");
		ph_no=R.nextInt();
		
		System.out.println("enter the valid name");
		Student_name=R.next();
		
		
		System.out.println("name is  "+Student_name);
		System.out.println("name is  "+roll_no);
		System.out.println("name is  "+marks);
		System.out.println("name is  "+ph_no);

		
		
		
		

	}

}


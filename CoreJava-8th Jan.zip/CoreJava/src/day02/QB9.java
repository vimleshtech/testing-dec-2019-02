package day02;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class QB9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s =new Scanner(System.in);
		int hs,es,cs,ms,ss,total;
		double avg;
		
		System.out.println("enter mark in h");
		hs = s.nextInt();
		
		System.out.println("enter mark in e");
		es = s.nextInt();
		
		System.out.println("enter mark in m");
		ms = s.nextInt();
		
		System.out.println("enter mark in s");
		ss = s.nextInt();
		
		System.out.println("enter mark in c");
		cs = s.nextInt();
		
		
		total = hs+es+cs+ms;
		avg= total/5;
		
		System.out.println("Total score is "+total);
		System.out.println("average score is"+avg);
		
		if(avg>=60) {
			System.out.println("First");
		}
		else if(avg>= 50 )
		{
			
			System.out.println("Second");
		}
		else if(avg>=40) {
			
			System.out.println("Third");
		}else {
			System.out.println("Fail");
		}
	}

}

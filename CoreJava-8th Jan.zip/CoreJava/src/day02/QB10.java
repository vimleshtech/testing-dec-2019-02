package day02;

import java.util.Scanner;

public class QB10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner(System.in);
		int unit;
		float amt;
		
		System.out.println("enter unit");
		unit = s.nextInt();
		
		if(unit<=100) {
			
			amt = unit*.40f;
		}
		else if(unit<=300) {
			
			amt = 40+(unit-100)*.50f;
			
		}else {
			
			amt = 140+(unit-300)*.60f;
		}
		
		amt+=50; //amt = amt+50
		System.out.println("total amt to be paid :"+amt);
		

	}

}

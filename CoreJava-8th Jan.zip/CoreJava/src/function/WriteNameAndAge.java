package function;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class WriteNameAndAge {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		FileWriter fw =new FileWriter("C:\\Users\\vkumar15\\Desktop\\amans.txt");
		BufferedWriter bw =new BufferedWriter(fw);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Temperature");
		int a=sc.nextInt();
		System.out.println("Press 1 for Fahrenheit to Celsius");
		int b=sc.nextInt();
		
		if(b==1) {
			double c =(a*1.8)+32;
			bw.write(""+c);
		}
		else if(b==2)
		{
			double c =(a-32)*5/9;
			bw.write(""+c);
		}
		bw.close();
		fw.close();
		
			
		
		System.out.println("file is saved");
		
		

	}

}

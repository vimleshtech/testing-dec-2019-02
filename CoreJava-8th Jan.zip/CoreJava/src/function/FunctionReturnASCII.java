package function;

public class FunctionReturnASCII {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Write a function that accepts a character as argument and returns its ASCII value.
    char d=Char();
    int f=d;
    System.out.println(f);
    
    
	}
	public static char Char() {
	char c='a';
			return c;
	}
}


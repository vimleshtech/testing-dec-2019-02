package function;

import java.util.Scanner;

public class FunctionExample {

	public static void main(String[] args) {
		

		//call to function 
		welcome();
		welcome();
		
		int x = getNum();
		int y = getNum();
		System.out.println(x+y);
		
		//add
		add(33,55);
		add(566,777);
		
		//
		int d = sub(5556,66);
		System.out.println(d);
		
	}
	
	//No argument no return
	public static void welcome() {
		
		System.out.println("welcome to function world...!");
	}
	//No argument with return
	public static int getNum() {
		
		Scanner sc = new Scanner(System.in);
		int n;
		System.out.println("ENTER DATA");
		n  = sc.nextInt();
		return n;
	}
	
	//ARGUMENT WITH NO RETURN
	public static void add(int a, int b) {
		int c=a+b;
		System.out.println("sum of two values "+c);
	}
	//ARGUMENT WITH RETURN
	public static int sub(int a, int b) {
		int c=a-b;
		return c;
		
	}	
	

}

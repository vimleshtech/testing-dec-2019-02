package function;

public class FunctionForOneINT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int d = Cube(6);
		System.out.println("Cube of Number is :"+d);
		//Write a function to calculate the cube of a number.
		
		int b = square(5);
		System.out.println("Sqaure of Number is :"+b);
		//Write a function that takes one integer argument and returns its square.
		
		
		float f = areaCir(5);
		System.out.println("Sqaure of Number is :"+f);
		//Write a function to calculate the area of a circle where radius is passed to the function as argument.

	}
	public static int Cube(int a) {
		int c=a*a*a;
		return c;
	}
	
	public static int square(int a) {
		int c=a*a;
		return c;
	}
	public static float areaCir(int r) {
		float c=(2*3.14f*r);
		return c;
	}
}

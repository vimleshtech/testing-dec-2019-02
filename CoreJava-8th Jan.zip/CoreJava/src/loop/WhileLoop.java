package loop;

public class WhileLoop {

	public static void main(String[] args) {

		
		int i=1; //init
		while(i<=10) {
			
			//System.out.println(i);
			System.out.print(i); //print in same line
			i++; //increment
		}
		//print in reverse order
		i=10;
		while(i>0) {
			System.out.println(i);
			i--;
		}
	
		//wap to get sum of all even and odd numbers between two given number
		int a=1,se=0,so=0; //init 
		while(a<100) { //condition 
			
			if(a%2==0) {
					se=se+a;
			}else {
				so=so+a;
			}
			a++; //increment 
		}
		
		System.out.println(se);
		System.out.println(so);

	}

}

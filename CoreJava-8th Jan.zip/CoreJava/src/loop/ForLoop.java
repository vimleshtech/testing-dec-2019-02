package loop;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=1; i<10; i++) {
			System.out.println(i);
		}
		
		//in reverse
		for(int i=11; i>0; i--) {
			System.out.println(i);
		}
		
	}
	

}

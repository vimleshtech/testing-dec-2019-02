package loop;

public class AdvacneLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int s[] = {11,33,445,556};
		for(int d: s) { //advance loop or foreach 
			System.out.println(d);
		}
	}

}

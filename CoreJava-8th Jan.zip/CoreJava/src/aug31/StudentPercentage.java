package aug31;
import java.util.Scanner;
public class StudentPercentage 
{

	public static void main(String[] args) 
	{
	int eng,hindi,comp,sc, math=0,avg,sum,division;
		
	Scanner p=new Scanner(System.in);
	
	System.out.println("enter the marks of eng" );
	eng=p.nextInt();

	System.out.println("enter the marks of hindi" );
	hindi=p.nextInt();
	

	System.out.println("enter the marks of comp" );
	comp=p.nextInt();
	

	System.out.println("enter the marks of sc" );
	sc=p.nextInt();
	

	System.out.println("enter the marks of math" );
	math=p.nextInt();
	
	sum=hindi+eng+math+sc+comp;
	System.out.println("sum of all subject is" +sum);
	
	avg=sum/5;
	System.out.println("average is" +avg);
	if (avg>=60)
		System.out.println("first division");
	else if (avg>=50)
		System.out.println("second division");
	else if (avg>=40 )
		System.out.println("third division");
	else if (avg<40)
	System.out.println("dont come to the class you are failed ");
	}

}

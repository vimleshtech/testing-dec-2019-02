package aug31;

import java.util.Scanner;

public class IfWithAnd {

	public static void main(String[] args) {

		int a,b,c;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter num ");
		a =sc.nextInt();
		
		System.out.println("enter num ");
		b =sc.nextInt();
		
		System.out.println("enter num ");
		c =sc.nextInt();
		
		
		//show greater number from three input
		if(a>b && a>c) {
			
			System.out.println("a is greater");
		}
		else if(b>a && b>c) {
			
			System.out.println("b is greater");
			
		}else {
			System.out.println("c is greater");
		}
		

	}

}

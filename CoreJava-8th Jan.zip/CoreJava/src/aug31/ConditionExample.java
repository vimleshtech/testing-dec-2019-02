package aug31;

import java.util.Scanner;

public class ConditionExample {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter sale amt ");
		int sales =sc.nextInt();		
		double tax=0,total ;
		
		//if condition : Exampe 1		
		if(sales>1000)
		{
			tax = sales*.18; //18% tax  : sales*18/100			
		}
		
		total = sales+tax;
		System.out.println("total amt "+total);
		
		///if else : example 2
						
		if(sales>1000)
		{
			tax = sales*.18; //18% tax  : sales*18/100			
		}
		else {
			
			tax = sales*.12;
		}
		
		total = sales+tax;
		System.out.println("total amt "+total);
		
		
		//if else if else if .... else : example 3
		if(sales>1000)
		{
			tax = sales*.18; //18% tax  : sales*18/100			
		}
		else if(sales>500){
			
			tax = sales*.12;
		}
		else if(sales>200){
			
			tax = sales*.10;
		}
		else {
			tax = sales*.05;
		}
		
		total = sales+tax;
		System.out.println("total amt "+total);
		
		
		
	}

}

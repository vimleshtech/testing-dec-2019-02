package aug31;

import java.util.Scanner;

public class SalaryCalculation
{

	public static void main(String[] args)
	{
	
		Scanner aug= new Scanner(System.in); 
		
		int salary;
		double DA,HRA;
		
		System.out.println("Enter the salary");
		salary =aug.nextInt();
		
		if (salary>=5000 && salary<=10000 )
		{
			HRA=salary*.10;
			DA=salary*.05;
			
		}
		else if (salary>=10001 && salary<=15000 )
		{
			HRA=salary*.15;
			DA=salary*.08;
		}
		else {
			HRA=0;
			DA=0;
		}
		System.out.println("HRA is "+HRA);
		System.out.println("DA is "+DA);
	}

}

package aug31;
import java.util.Scanner;
public class Electricity_Bill_Charge 
{

	public static void main(String[] args) 
	{
		
	Scanner c = new Scanner(System.in);	
    int meter_charges=50;
    int unit; 
    double charge=0;
    
   
    System.out.println("Please enter Bill unit");
	unit=c.nextInt();
	
	 if (unit<=100)
	 {	
	    	charge=unit*.4;
	 		//charge = charge+meter_charges;
	 }
	//System.out.println("you are suppose to pay "+charge);
	
	 else if (unit<=300)
	{
			charge=unit*.5;
	 		//charge=charge+meter_charges;
	}
		//System.out.println("now you pay "+charge);
	 else 
	{
		charge=unit*.6;
 		
	}
	 charge = charge+meter_charges;
	 
		System.out.println(" now you have to pay "+charge);
	}
}

package day07;

public class class2 extends dcalc {

	
}

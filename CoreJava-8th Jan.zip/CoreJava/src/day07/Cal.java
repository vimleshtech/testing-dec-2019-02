package day07;

public class Cal {

	int a;
	
	void add(int a, int b) {
		System.out.println(a+b);
	}

	void add(double a, double b) {
		System.out.println(a+b);
	}

	void sub(int a, int b) {
		System.out.println(a-b);
	}

	void div(int a, int b) {
		System.out.println(a/b);
	}

	
}

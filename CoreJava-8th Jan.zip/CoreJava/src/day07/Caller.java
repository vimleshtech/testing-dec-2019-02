package day07;

import java.util.Scanner;

public class Caller {

	public static void main(String[] args) {

		
		Student s[] = new Student[4];
		for(int i=0; i<4;i++) {
			s[i] = new Student();
			s[i].input();
		}
		
		//sorting
		for(int i=0; i<4;i++) {
		
			for(int j=i+1; j<4;j++) {
				
				if(s[i].retno()>s[j].retno()) {
					
					Student temp = s[i];
					s[i]=s[j];
					s[j] = temp;
				}
				
			}
			
		}
		
		
		//print 
		for(int i=0; i<4;i++) {
		
			s[i].disp();
		}
		
		
		//search 
		Scanner sc = new Scanner(System.in);
		System.out.println("enter rno to search ");
		int rn = sc.nextInt();
		
		for(int i=0; i<4;i++) {
			if(s[i].retno() == rn)
				s[i].disp();
		}
		
		
		
	}

}

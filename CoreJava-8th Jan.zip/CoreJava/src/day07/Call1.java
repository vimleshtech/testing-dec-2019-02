package day07;

import java.util.Scanner;

public class Call1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConstructorExample c = new ConstructorExample();		
		
		ConstructorExample c1 = new ConstructorExample("india");
		ConstructorExample c2 = new ConstructorExample("us");
		
		c.disp();
		c1.disp();
		c2.disp();
		
		//ArithmeticException e= new ArithmeticException("divisor cann ..");
		//Scanner s = new Scanner(System.in);
		
		ConstructorExample c3 = new ConstructorExample(c2);
		c3.disp();
		
		///call 
		
		dcalc dc = new dcalc();
		dc.add(11, 11);
		dc.add(11, 11.444);
		dc.add(11.333, 11.44);
		dc.add(11, 11,444);
		
		dc.sub(11, 11);
		dc.mul(11, 11);
		dc.tax(111);
		
		
	}

}

package day07;

import java.util.Scanner;

public class Student {

	int rollno;//		-roll number
	String name;//	- name
	String address;//	-address of the student
	String city;		//-city of the student	
	String country;//	-country of the student
	
	void input() {
		
		Scanner s =new Scanner(System.in);
		System.out.println("enter rno");
		rollno = s.nextInt();
		
		System.out.println("enter name");
		name= s.next();
				
		System.out.println("enter address");
		address= s.next();
		
		
		System.out.println("enter city");
		city= s.next();
		
		System.out.println("enter country");
		country = s.next();
		
		
	}
	int retno() {
		return rollno; 
	}
	void disp() {
		
		System.out.println("rno :"+rollno);
		System.out.println("name :"+name);
		System.out.println("address :"+address);
		System.out.println("city :"+city);
		System.out.println("country :"+country);
		
	}


	
}

package day07;

public class ConstructorExample {

	int amt;
	double tax;
	
	
	ConstructorExample(){
		System.out.println("object is created");
		amt  =0;
		tax = 10;
		
	}
	
	ConstructorExample(String country){
		
		System.out.println("object is created");
		if(country.equals("india"))
		{
			amt  =0;
			tax = 10;
		}
		else {
			amt  =10;
			tax = 100;
		}
		
	}
	
	ConstructorExample(ConstructorExample  o){ //copy constrctor
		
		this.amt = o.amt;
		this.tax = o.tax;
	}
	void disp() {
		System.out.println(amt);
		System.out.println(tax);
		
		
		tax = tax*1.10;
		
	}
	
}

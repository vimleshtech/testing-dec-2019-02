package day07;

public class dcalc extends Cal {

	//int a;
	
	void mul(int a, int b) {
		System.out.println(a*b);
		
		a =10;
		this.a= 100;
		super.a =440;//super in parent class 
		
	}

	

	void add(int a, int b,int c) {
		System.out.println(a+b+c);
	}

	
	void tax(int amt) {
		System.out.println(amt*.18);
	}

	
	
}

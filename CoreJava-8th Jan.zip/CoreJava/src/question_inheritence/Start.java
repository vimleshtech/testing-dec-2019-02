package question_inheritence;

public class Start {

	public static void main(String[] args) {

		SClass o = new SClass();
		o.test();
		
		SClass.b.sub();

		SClass.b oo = new SClass.b();
		oo.test();
		oo.sub();
		
		System.out.println( o.getClass());
		System.out.println( o.hashCode());
	
		
		ChildClass co = new ChildClass();
		co.add();
		//co.test();
		
	}
	

}

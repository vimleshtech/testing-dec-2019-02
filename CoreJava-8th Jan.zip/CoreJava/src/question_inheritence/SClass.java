package question_inheritence;

public class SClass {

	void test() {
		
			c o = new c();
			o.test();
			c.add();
			
			b oo = new b();
			oo.test();
			b.sub();
			oo.sub();
			
	}

	public static class b{
		
		void test() {
			System.out.println("in satic innner class test");
		}
		static void sub() {
			System.out.println("in satic innner class sub");
		}
	}
	
	static class c{
		
		void test() {
			System.out.println("in inner class test");
		}
		
		static void add() { System.out.println("in add ");}
	}
}


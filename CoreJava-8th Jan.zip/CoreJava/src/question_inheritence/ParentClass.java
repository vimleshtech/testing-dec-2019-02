package question_inheritence;

public class ParentClass {

	ParentClass(){
		System.out.println("in parent ");
	}
	void test() {
		System.out.println("hi");
	}
}

package question_inheritence;

import java.util.Scanner;

public class ChildClass extends ParentClass {

	ChildClass(){
		System.out.println("in child constructor");
	}
	void add() {
		System.out.println("add");
	}
	
}

package day072;

public class AbsImpls extends AbstractClass {

	@Override
	void sub(int a, int b) {
		// TODO Auto-generated method stub

		System.out.println(a-b);
	}

	@Override
	int div(int a, int b) {
		// TODO Auto-generated method stub
		return a/b;
	}

	@Override
	void mul(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a*b);
		
	}

}

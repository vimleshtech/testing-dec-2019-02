package day072;

public abstract class AbstractClass {

	
	void add(int a, int b) {
		System.out.println(a+b);
	}
	
	abstract void sub(int a, int b); 
	abstract int div(int a, int b);
	abstract void mul(int a, int b);
	
}

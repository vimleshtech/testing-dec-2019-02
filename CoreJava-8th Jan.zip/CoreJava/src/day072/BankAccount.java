package day072;

import java.util.Scanner;

public class BankAccount {

	int acno;
	String aname;
	String pan;
	
	Scanner sc = new Scanner(System.in);
	
	void newAccount() {
	
		System.out.println("enter acno");
		acno = sc.nextInt();
		System.out.println("enter name");
		aname = sc.next();
		System.out.println("enter pan");
		pan = sc.next();
			
	}
	
	void dispAccount() {
		
		System.out.println("acno "+acno);
		
		System.out.println("name "+aname);
		
		System.out.println("pan "+pan);
		
			
	}
	
	
}

package day072;

public class SavingAccount extends BankAccount { 

	String address;
	String id;
	
	void newAccount() {
	
		super.newAccount();
		System.out.println("enter address");
		address= sc.next();
		System.out.println("enter id");
		id= sc.next();
			
	}
	
	void dispAccount() {
		super.dispAccount();
		
		System.out.println("address "+address);		
		System.out.println("id "+id);
			
	}
	
	
}

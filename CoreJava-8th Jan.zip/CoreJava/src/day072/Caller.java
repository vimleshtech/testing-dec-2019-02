package day072;

public class Caller {

	public static void main(String[] args) {
		
		BankAccount ba = new CurrentAccount();
		BankAccount sa = new SavingAccount();
		
		ba.newAccount();
		sa.newAccount();
		
		ba.dispAccount();
		sa.dispAccount();
		
		
		
	}

}

package questions_abstract;

public class Startup {

	public static void main(String[] args) {

		AbstractA.c =100;
		System.out.println(AbstractA.c);
		
		AbstractA.add();

		//AbstractA o = new AbstractA();
		AbstractA.perc();
		///
		AbstractA o = new ClassExtends();
		System.out.println(o.a);
		System.out.println(o.b);
		System.out.println(o.c);
		
		ClassExtends oo = new ClassExtends();
		
	}

}

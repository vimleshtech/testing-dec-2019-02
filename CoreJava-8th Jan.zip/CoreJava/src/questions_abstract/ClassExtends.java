package questions_abstract;

public class ClassExtends extends AbstractA {

	//int b;
	final int b=10;
	
	@Override
	void mul() {
		// TODO Auto-generated method stub
		System.out.println("in child class mul fun");
		int b=1000;
		
		System.out.println(b);
		System.out.println(this.b);
		System.out.println(super.b);
	}

	static void add() { 
		
		System.out.println("in abstract static add");
	}
	
	void sub() { 
		
		System.out.println("in abstract  sub");
	}
	
	
	
}

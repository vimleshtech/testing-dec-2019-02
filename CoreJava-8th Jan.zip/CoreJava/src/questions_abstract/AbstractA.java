package questions_abstract;
//Abstract class can have constructor 
//Abstract class can static method 
//Abstract class cannot have static with abstract  method

public abstract class AbstractA {
	int a;
	final int b=1;
	static int c;
	
	AbstractA(){
	
		System.out.println("in AbstractA");
	}
	
	static void add() { 
		
		System.out.println("in abstract static add");
	}
	
	void sub() { 
		
		System.out.println("in abstract  sub");
	}
	
	final void div() { 
		
		System.out.println("in abstract  sub");
	}
	static final void perc() { 
		
		System.out.println("in abstract  sub");
	}
	
	abstract void mul();
	
}

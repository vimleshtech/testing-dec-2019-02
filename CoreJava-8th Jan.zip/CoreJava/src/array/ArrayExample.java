package array;

public class ArrayExample {

	public static void main(String[] args) {

		int n[]= new int[3];
		n[0] =1;
		n[1] =41;
		n[2] =51;
		
		System.out.println(n.length); //print length
		System.out.println(n[1]); //print 2nd value 
		
		//interate 
		for(int i=0; i<n.length;i++) {
			System.out.println(n[i]);
		}
		
		////
		String s[] = {"hi","test","hello"};
		
		System.out.println(s.length); //print length
		System.out.println(s[1]); //print 2nd value 
		
		//interate 
		for(int i=0; i<s.length;i++) {
			System.out.println(s[i]);
		}
		
		//2 d
		String ss[][] = new String[2][3];
		ss[0][0]= "555";
		ss[0][1]= "555";
		ss[0][2]= "555";

		ss[1][0]= "555";
		ss[1][2]= "555";
		ss[1][2]= "555";
		
		System.out.println(ss.length); //row length
		System.out.println(ss[0].length); //col length
		
		System.out.println(ss[0][1]); // first row 2nd col
		for(int i=0; i<ss.length;i++) {
			for(int j=0; j<ss[i].length;j++) {
				
				System.out.print(ss[i][j]+"\t");
			}
			System.out.println();
		}
	}

}

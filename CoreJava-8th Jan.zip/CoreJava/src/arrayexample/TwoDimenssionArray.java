package arrayexample;

public class TwoDimenssionArray {

	public static void main(String[] args) {

		String s[][] = {{"alpha","beta"},{"test","test"},{"abdfd"}};
		
		//read by index
		System.out.println(s[0][1]);
		
		
		//iterate the loop
		for(String ss[] : s) {
			
			for(String t: ss) {
				System.out.println(t);
			}
			
		}

	}

}

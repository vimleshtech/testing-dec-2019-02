package arrayexample;

public class Test {

	int data;
	
	void a() {
		System.out.println("a function");
	}
	
	//declration of constructor 
	Test(){
		System.out.println("test ");
	}
	
	//with argument 
	Test(String country){
		if(country.equals("india"))
			System.out.println("test ");
		else
			System.out.println("hello");
	}
	
	//copy constructor 
	
	Test (Test o){
		this.data = o.data;
	}
	
	void show() {
		System.out.println(data);
	}
}
